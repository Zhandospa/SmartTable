import 'package:flutter_riverpod/flutter_riverpod.dart';

final sessionProvider = StateProvider<String?>((ref) => null);